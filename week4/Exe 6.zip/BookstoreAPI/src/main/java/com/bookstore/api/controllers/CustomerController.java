package com.bookstore.api.controllers;

import  com.bookstore.api.controllers.Customer;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    // 1. Define the customers list
    private List<Customer> customers = new ArrayList<>();

    // 2. Add a new customer via form data
    @PostMapping("/register")
    public String registerCustomer(@RequestParam String name,
                                   @RequestParam String email,
                                   @RequestParam String password) {
        // Create a new Customer and add it to the list
        Customer customer = new Customer((long) (customers.size() + 1), name, email, password);
        customers.add(customer);
        return "Customer registered successfully!";
    }

    // Other customer-related endpoints can go here...
}

