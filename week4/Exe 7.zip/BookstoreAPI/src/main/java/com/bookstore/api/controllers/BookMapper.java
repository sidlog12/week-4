package com.bookstore.api.controllers;

import com.bookstore.api.controllers.*;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BookMapper {
    BookDTO toDto(Book book);
    Book toEntity(BookDTO bookDto);
}

